package com.medicine.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="User_signup")
public class U_Signup {

	@Id
	@GeneratedValue
	@Column(name="u_id")
	private int u_id;
	
	@Column(name="firstname")
	private String firstname;
	
	@Column(name="lastname")
	private String lastname;
	
	@Column(name="email")
	private String email;
	
	
	
	@Column(name="dob")
	
	private String dob;
	
	@Column(name="gender")
	private String gender;
	
	@Column(name="contact_no")
	private int contact_no;

	@Column(name="password")
	private String password;

	public U_Signup(int u_id, String firstname, String dob, String gender, int contact_no, String lastname, String password,String email) {
		super();
		this.u_id = u_id;
		this.firstname = firstname;
		this.dob = dob;
		this.gender = gender;
		this.contact_no = contact_no;
		this.lastname = lastname;
		this.password = password;
		this.email=email;
	}
	
	public U_Signup()
	{
		
	}

	public int getu_id() {
		return u_id;
	}

	public void setu_id(int u_id) {
		this.u_id = u_id;
	}

	public String getfirstname() {
		return firstname;
	}

	public void setfirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getlastname() {
		return lastname;
	}

	public void setlastname(String lastname) {
		this.lastname = lastname;
	}

	public String getemail() {
		return email;
	}

	public void setemail(String email) {
		this.email = email;
	}

	public String getgender() {
		return gender;
	}

	public void setgender(String gender) {
		this.gender = gender;
	}

	public int getcontact_no() {
		return contact_no;
	}

	public void setcontact_no(int contact_no) {
		this.contact_no = contact_no;
	}

	public String getdob() {
		return dob;
	}

	public void setdob(String dob) {
		this.dob = dob;
	}

	public String getpassword() {
		return password;
	}

	public void setpassword(String password) {
		this.password = password;
	}

}