package com.medicine.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="medicines")
public class Medicine {
	@Id
	@Column(name="medname")
	private String medname;
	@Column(name="medid")
	private int medid;
	@Column(name="price")
	private int price;
	@Column(name="manfdate")
	private String  manfdate;
	@Column(name="expdate")
	private String  expdate;
	@Column(name="status")
	private String  status;
	@Column(name="description")
	private String  description;
	public  Medicine (String medname, String manfdate,String expdate,String status,String description, int medid,int price ) {
        super();
        this.medname = medname;
        this.manfdate = manfdate;
        this.expdate=expdate;
        this.status=status;
        this.medid=medid;
        this.price=price;
        this.description=description;
    }
	public Medicine() {
		// TODO Auto-generated constructor stub
	}

	
	public String getmedname() {
		return medname;
	}
	public void setmedname(String medname) {
		this.medname= medname;
	}
	public int  getmedid() {
		return medid;
	}
	public void setmedid(int medid) {
		this.medid= medid;
	}
	public int  getprice() {
		return price;
	}
	public void setprice(int price) {
		this.price= price;
	}
	

public String getmanfdate() {
	return manfdate;
}
public void setmanfdate(String manfdate) {
	this.manfdate = manfdate;
}
public String getexpdate() {
	return expdate;
}
public void   setexpdate(String expdate) {
	this.expdate = expdate;
}
public String getdescription() {
	return description;
}
public void   setdescription(String description) {
	this.description = description;
}
}
