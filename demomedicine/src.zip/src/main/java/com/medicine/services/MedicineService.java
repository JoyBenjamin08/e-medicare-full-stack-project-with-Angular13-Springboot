package com.medicine.services;


import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicine.model.Medicine;
import com.medicine.repository.MedicineRepository;


@Service
public class MedicineService {

	@Autowired
	MedicineRepository medRepository;
	
	@Transactional
	public List<Medicine> fetchmedicines() {
		List<Medicine> medList=medRepository.findAll();
		return medList;
		
	}
	@Transactional
	public Medicine saveMedicines(Medicine medicines) {
		
		return medRepository.save(medicines);
		
	}
	@Transactional
	public void updateMedicines(Medicine med) {
		medRepository.save(med);	
	
	}
	
	@Transactional
	public void deleteMedicines(int medid) {	
		System.out.println("service method called");
		medRepository.deleteById(medid);
	
	}
	@Transactional 
	  public Medicine getMedicines(int medid) { 
	  Optional<Medicine> optional= medRepository.findById(medid);
	  Medicine med=optional.get();
	  return med;
	  

}
}
