package com.medicine.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicine.exception.ResourceNotFoundException;
import com.medicine.model.Medicine;
import com.medicine.services.MedicineService;




//@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v4")
@RestController
public class MedicineController {

	@Autowired
	MedicineService medService;
	@GetMapping("/getAllMedicines")
	public List<Medicine> getMedicines() {
		List<Medicine> medList = medService.fetchmedicines();
		return  medList;
	}
	@GetMapping("/getMedicines/{medid}")
	public ResponseEntity<Medicine> getMedicinesBymedid(@PathVariable("medid") int medid)
			throws ResourceNotFoundException {
		Medicine medicines = medService.getMedicines(medid);
		return ResponseEntity.ok().body(medicines);
	}
	@PostMapping("/saveMedicines")
	public Medicine addMedicines(@RequestBody Medicine med) {

		Medicine medicines = medService.saveMedicines(med);

		return medicines;
	}

	@PutMapping("/updateMedicines/{medid}")
	public ResponseEntity<Medicine> updateMedicines(@PathVariable("medid") int medid,
			@RequestBody Medicine medicinesDetails) throws ResourceNotFoundException {
		Medicine medicines = medService.getMedicines(medid);

		medicines.setmedname(medicinesDetails.getmedname());
		medicines.setmedid(medicinesDetails.getmedid());
		medicines.setmanfdate(medicinesDetails.getmanfdate());
		medicines.setexpdate(medicinesDetails.getexpdate());
		medicines.setprice(medicinesDetails.getprice());
		medicines.setdescription(medicinesDetails.getdescription());
		final Medicine updatedMedicines = medService.saveMedicines(medicines);
		return ResponseEntity.ok(updatedMedicines);
	}

	@DeleteMapping(value = "/deleteMedicines/{medid}")
	public ResponseEntity<Object> deleteMedicines(@PathVariable("medid") int medid) {

		medService.deleteMedicines(medid);
		return new ResponseEntity<>("medicines deleted successsfully", HttpStatus.OK);
	}
	
}
