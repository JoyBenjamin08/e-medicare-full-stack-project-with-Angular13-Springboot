package com.medicine.demomedicine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemomedicineApplicationTests {

	@Test
	void contextLoads() {
	}

}
